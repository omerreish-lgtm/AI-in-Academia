# הנחיות מפורטות ליצירת מצגת: אסטרטגיית AI לפקולטה למשפטים

## מסמך הנחיות לסוכן חיצוני | גרסה 1.0 | דצמבר 2025

---

## חלק א': מפרט טכני

### 1.1 Workflow נדרש

```
HTML (960×540px) → html2pptx → PPTX → PDF → Visual Validation
```

**שלבי ביצוע:**
1. חילוץ ספריית html2pptx: `mkdir -p html2pptx && tar -xzf skills/public/pptx/html2pptx.tgz -C html2pptx`
2. יצירת קבצי HTML נפרדים לכל שקף (slide01.html עד slide11.html)
3. יצירת קובץ CSS משותף (mckinsey-rtl.css)
4. יצירת סקריפט Node.js להמרה
5. הרצה: `NODE_PATH="$(npm root -g)" node build-presentation.js 2>&1`
6. ולידציה ויזואלית: `soffice --headless --convert-to pdf output.pptx && pdftoppm -jpeg -r 150 output.pdf slide`
7. בדיקת כל תמונה לחיתוך טקסט, חפיפות, בעיות RTL

### 1.2 מפרט עיצובי

#### פונטים
```css
--font-primary: 'Assistant', 'Arial Hebrew', sans-serif;
--font-size-action-title: 28px;
--font-size-subtitle: 16px;
--font-size-body: 14px;
--font-size-table-header: 13px;
--font-size-table-cell: 12px;
--font-size-footnote: 10px;
--font-size-source: 9px;
```

#### פלטת צבעים
```css
/* צבעי בסיס */
--color-navy: #051C2C;           /* כותרות ראשיות */
--color-dark-gray: #333333;      /* טקסט גוף */
--color-medium-gray: #666666;    /* טקסט משני */
--color-light-gray: #F5F5F5;     /* רקע משני */
--color-white: #FFFFFF;          /* רקע ראשי */

/* צבעי הדגשה */
--color-accent-blue: #0066CC;    /* הדגשה חיובית */
--color-highlight: #00A3E0;      /* קישורים, אייקונים */
--color-success: #00875A;        /* ירוק - חיובי */
--color-warning: #FF6B00;        /* כתום - אזהרה */
--color-danger: #E31B23;         /* אדום - שלילי/דחוף */

/* צבעי טבלאות */
--table-header-bg: #051C2C;
--table-header-text: #FFFFFF;
--table-row-odd: #FFFFFF;
--table-row-even: #F8F9FA;
--table-border: #E0E0E0;
```

#### כיווניות RTL
```css
html { direction: rtl; }
body { 
  direction: rtl; 
  text-align: right;
  width: 960px;
  height: 540px;
}
.bullet-list { 
  list-style-position: inside;
  padding-right: 0;
  margin-right: 20px;
}
table { direction: rtl; }
th, td { text-align: right; }
td.number { text-align: left; } /* מספרים יישור שמאל */
```

### 1.3 מבנה שקף סטנדרטי

```
┌─────────────────────────────────────────────────────────────┐
│  ZONE 1: Action Title (גובה: 60px, padding: 20px)          │
│  כותרת פעולה - משפט שלם עם תובנה                           │
├─────────────────────────────────────────────────────────────┤
│  ZONE 2: Content (גובה: 420px)                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  תוכן ראשי: טבלאות, תרשימים, bullets              │   │
│  │  Padding: 20px מכל הצדדים                          │   │
│  └─────────────────────────────────────────────────────┘   │
├─────────────────────────────────────────────────────────────┤
│  ZONE 3: Footer (גובה: 40px)                               │
│  [מקור: ציטוט]                              [מספר שקף]    │
└─────────────────────────────────────────────────────────────┘
```

---

## חלק ב': תוכן השקפים - 11 שקפים

---

### שקף 1: כותרת

**סוג:** Title Slide  
**Action Title:** הפקולטה למשפטים יכולה להוביל את מהפכת ה-AI בישראל – או לרדוף אחריה

**תת-כותרת:** הצעה לאסטרטגיית AI-first לפקולטה למשפטים, האוניברסיטה העברית

**עיצוב:**
- רקע: לבן נקי
- כותרת: מרכז, צבע navy (#051C2C), font-weight: 700, font-size: 36px
- תת-כותרת: מרכז, צבע medium-gray, font-size: 18px
- לוגו אוניברסיטה: פינה שמאלית תחתונה (אם זמין)
- קו מפריד דק בצבע accent-blue מתחת לכותרת

**HTML Template:**
```html
<div class="title-slide">
  <div class="title-container">
    <h1 class="main-title">הפקולטה למשפטים יכולה להוביל את מהפכת ה-AI בישראל – או לרדוף אחריה</h1>
    <div class="divider"></div>
    <h2 class="subtitle">הצעה לאסטרטגיית AI-first לפקולטה למשפטים, האוניברסיטה העברית</h2>
  </div>
  <div class="footer">
    <span class="date">דצמבר 2025</span>
  </div>
</div>
```

---

### שקף 2: הזירה

**סוג:** Context Slide  
**Action Title:** כל השחקנים סביב הפקולטה כבר זזים – הפקולטה עומדת במקום

**תוכן ויזואלי:** אינפוגרפיקה מרכזית - הפקולטה במרכז, לחצים מ-4 כיוונים

**מבנה התוכן:**

```
                    [למעלה: רגולציה וחינוך]
                    • אין הנחיות מל"ג לשימוש סטודנטים
                    • מחקר אקדמי כבר נעזר ב-AI
                              ↓
[שמאל: מקצוע]                              [ימין: מתחרים]
• לשכת עוה"ד (ABA Opinion 512)  ←  [פקולטה]  →  • בר-אילן: מדיניות מלאה
• משרדים מאמצים Harvey, CoCounsel              • ראשונה בישראל (2024)
                              ↑
                    [למטה: סטודנטים ובתי משפט]
                    • 86% סטודנטים משתמשים
                    • 486 מקרי הזיות בבתי משפט
```

**Bottom Line (בתיבה מודגשת):**
> אף פקולטה למשפטים בישראל לא פרסמה הנחיות שימוש AI לסטודנטים

**צבעים:**
- חיצים/לחצים: אדום (#E31B23)
- הפקולטה במרכז: אפור (#666666)
- תיבת Bottom Line: רקע צהוב בהיר (#FFF3CD), גבול כתום

**מקור:** Digital Education Council 2024; ABA Formal Opinion 512; מדיניות בר-אילן 2024

---

### שקף 3: הבעיה המשולשת

**סוג:** Problem Definition  
**Action Title:** שלוש רמות, שורש אחד: היעדר חזון AI-first

**תוכן - טבלה בת 3 שורות:**

| רמה | מצב נוכחי | תוצאה |
|-----|-----------|-------|
| **מוסדית** | אין מדיניות, עיוורון מכוון או איסור | אי-ודאות, "אזור אפור" |
| **מרצים** | חוסר אוריינות, חשש, ניתוק מהמציאות | לא יכולים להנחות או להעריך |
| **סטודנטים** | 86% משתמשים ללא הכוונה | לא מוכנים לשוק העבודה |

**שורש הבעיה (תיבה נפרדת בתחתית):**
> התייחסות ל-AI כאיום או כגימיק – לא כתשתית חדשה לעבודה משפטית

**עיצוב:**
- 3 עמודות/שכבות עם חץ יורד מ"מוסדית" ל"סטודנטים"
- חץ עולה חזרה (השפעה הדדית)
- צבעים מדורגים: כחול כהה (מוסדית) → כחול בינוני → כחול בהיר (סטודנטים)
- תיבת שורש: רקע אדום בהיר, טקסט כהה

**מקור:** Digital Education Council 2024; סקר HIT 2023

---

### שקף 4: העלות

**סוג:** Data Slide  
**Action Title:** היעדר מדיניות יוצר אי-שוויון רב-ממדי בין הסטודנטים

**תוכן - שתי טבלאות:**

**טבלה עליונה: 4 פערים**

| פער | תיאור | נתון |
|-----|-------|------|
| **ידע ומיומנות** | מי יודע לעומת מי לא | 58% מרגישים חוסר ידע |
| **נגישות כלכלית** | כלים בתשלום נגישים רק לחלק | ChatGPT Plus: $20/חודש |
| **רקע טכנולוגי** | פער מגדרי, פער בין-תחומי | 14 נק' אחוז פער גברים-נשים |
| **איכות שימוש** | שימוש שטחי לעומת מעמיק | 18% מעתיקים ישירות |

**טבלה תחתונה: סיכון ייחודי למשפטים - שיעורי הזיות**

| מודל | שיעור הזיות בשאילתות משפטיות |
|------|------------------------------|
| ChatGPT 4 | **58%** |
| ChatGPT 3.5 | **69%** |
| Llama 2 | **88%** |
| Lexis+ AI | **17%+** |

**עיצוב:**
- טבלה עליונה: רקע לבן, headers בכחול כהה
- טבלה תחתונה: הדגשה באדום, אייקון אזהרה ⚠️
- אייקונים לכל פער בטבלה העליונה

**מקור:** HEPI/Kortext 2025; UC System 2024; Dahl et al. "Large Legal Fictions" 2024

---

### שקף 5: הדחיפות

**סוג:** Urgency Slide  
**Action Title:** חלון ההזדמנות נסגר – עלות ההמתנה גדלה מחודש לחודש

**תוכן - ציר זמן אופקי:**

**מה כבר קרה:**
- 486 מקרי הזיות AI מתועדים בבתי משפט גלובלית (324 בארה"ב)
- *Mata v. Avianca* (2023): קנס $5,000 – ChatGPT המציא 6 אסמכתאות
- *Wadsworth v. Walmart* (2025): קנס $3,000 – 8 אסמכתאות בדויות

**מה קורה עכשיו:**
- בר-אילן: מדיניות + צ'אטבוט עוזר הוראה (פיילוט 2024)
- ABA Opinion 512 קובע חובות אתיות לעורכי דין (יולי 2024)
- משרדים מובילים מטמיעים Harvey, CoCounsel

**מה יקרה אם נמתין:**
> "בוגרי הפקולטה ייכנסו לשוק עבודה שדורש מיומנויות שלא לימדנו אותם"

**עיצוב:**
- ציר זמן אופקי עם 3 נקודות
- חץ אדום מראה "הפער גדל"
- גרף פשוט של צמיחת הפער לאורך זמן
- ציטוט בתיבה מודגשת

**מקור:** Dahl et al. 2024; ABA 2024; מדיניות בר-אילן

---

### שקף 6: החזון

**סוג:** Vision Slide  
**Action Title:** פקולטה עם תרבות AI-first: מדיניות ברורה, סגל מיומן, סטודנטים עם חשיבה ביקורתית

**תוכן - 4 עקרונות מנחים:**

| עיקרון | משמעות |
|--------|--------|
| **עידוד, לא רק היתר** | לא "מותר להשתמש" אלא "מעודדים להשתמש נכון" |
| **הסתגלות, לא כלים** | ללמד יכולת למידה, לא רק הכשרה על כלי ספציפי |
| **שילוב, לא החלפה** | AI כמגביר יכולות, לא תחליף לחשיבה משפטית |
| **שקיפות** | מדיניות ברורה, לא "אזור אפור" |

**מודל השראה (תיבה נפרדת):**
```
שותפות Northwestern-Anthropic
• פיתוח כלי מותאם
• הכשרת סגל
• מחקר משותף
```

**עיצוב:**
- 4 אייקונים גדולים עם העקרונות
- תיבה נפרדת עם לוגו Northwestern כ-"proof of concept"
- צבעים חיוביים: ירוק, כחול

**מקור:** Northwestern-Anthropic Partnership 2024

---

### שקף 7: פער השימוש

**סוג:** Comparison Slide  
**Action Title:** ההבדל בין שימוש מיומן לבעייתי הוא ההבדל בין למידה לרמאות

**תוכן - שתי טבלאות זו לצד זו:**

**טבלה שמאלית (ירוקה): שימוש מיומן - מה שאנחנו רוצים**

| פעולה | דוגמה | תוצאה |
|-------|-------|-------|
| הסבר מושגים | "הסבר לי רשלנות לפי הפסיקה בשפה פשוטה" | הבנה מעמיקה |
| סיעור מוחות | "עזור לי לחשוב על טיעוני הגנה" | רעיונות חדשים |
| תרגול IRAC | "תן לי תרחיש לתרגול ובדוק את תשובתי" | הכנה לבחינה |
| עריכה | "שפר את הניסוח של הפסקה הזו" | כתיבה טובה יותר |
| אימות | "האם הטיעון שלי מכסה את כל היסודות?" | בקרת איכות |

**טבלה ימנית (אדומה): שימוש בעייתי - מה שקורה היום**

| פעולה | דוגמה | תוצאה |
|-------|-------|-------|
| העתקה | "כתוב לי תשובה לשאלה הזו" | אי-למידה |
| הזיות | "מצא לי פסק דין שתומך בטענה" | אסמכתאות בדויות |
| תלות | שימוש בלי הבנת מגבלות | החמצת שגיאות |
| אי-אימות | קבלת תשובות כ"אמת" | טעויות חמורות |

**כותרת מפרידה בין הטבלאות:**
> מה מבדיל? **הכוונה + מודעות + כלים**

**עיצוב:**
- שתי טבלאות זו לצד זו
- שמאל: רקע ירוק בהיר, headers ירוקים
- ימין: רקע אדום בהיר, headers אדומים
- קו מפריד ברור עם חץ וטקסט

**מקור:** HEPI/Kortext 2025; ניתוח פנימי

---

### שקף 8: המרצים כסוכני שינוי

**סוג:** Mechanism Slide  
**Action Title:** השינוי יעבור דרך המרצים – הם נקודת המנוף

**תוכן:**

**למה דווקא מרצים? (3 נקודות)**
- ממוקמים בין המוסד לסטודנטים
- קובעים מדיניות בפועל (ברמת הקורס)
- מעצבים תרבות שימוש

**טבלת 3 מחסומים:**

| מחסום | תיאור | נתון תומך |
|-------|-------|-----------|
| **מודעות** | לא יודעים את היקף השימוש בפועל | פער בין 86% בפועל להערכות מרצים |
| **מיומנויות** | לא מכירים כלים, לא יודעים להגיב | 70% סטודנטים חושבים שמרצים לא יזהו |
| **כלים** | חסרים אמצעים מתאימים | אין כלים משפטיים ייעודיים |

**עיצוב:**
- דיאגרמה: "מרצים" במרכז, חץ מ"מוסד" וחץ ל"סטודנטים"
- 3 מחסומים כ-X אדומים על הקשרים
- צבעים: כחול לדיאגרמה, אדום למחסומים

**מקור:** סקר HIT 2023; Digital Education Council 2024

---

### שקף 9: חבילת הפתרון - סקירה

**סוג:** Solution Overview  
**Action Title:** שלושה שלבים: קודם להבין, אחר כך להכשיר, ולבסוף לצייד

**תוכן - תרשים זרימה אופקי:**

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   מידול     │ ──→ │   הכשרה     │ ──→ │    כלי      │
│  (שלב 1)    │     │  (שלב 2)    │     │  (שלב 3)    │
└─────────────┘     └─────────────┘     └─────────────┘
       ↓                   ↓                   ↓
  להבין את הבעיה     להכשיר מרצים      לצייד סטודנטים
    בפועל                                      
```

**טבלת לוגיקה:**

| שלב | פותר מחסום | תוצאה |
|-----|------------|-------|
| מידול | מודעות | תמונת מצב מבוססת נתונים |
| הכשרה | מיומנויות | מרצים מסוגלים להנחות |
| כלי | כלים | גישה שוויונית ומונחית |

**עיצוב:**
- תרשים זרימה אופקי עם 3 תיבות וחיצים
- כל תיבה בצבע שונה (כחול, ירוק, סגול)
- טבלה קצרה מתחת

---

### שקף 10: שלב 1 - מידול

**סוג:** Solution Detail  
**Action Title:** אי אפשר לפתור בעיה שלא רואים – מתחילים במיפוי המציאות

**תוכן:**

**מה:** מיפוי דפוסי השימוש בפועל של סטודנטי הפקולטה

**למה:**
- הנחות המרצים לא תואמות את המציאות
- 86% משתמשים, 0% מדיניות = פער עצום
- "60%+ מהסטודנטים מאמינים שמרצים לא יכולים לצפות להתנהגות אתית ללא הדרכת AI" (סקר HIT)

**איך:**
- ☑️ סקר סטודנטים אנונימי
- ☑️ ראיונות עומק עם מרצים
- ☑️ ניתוח השוואתי למחקרים גלובליים

**תוצר:** דו"ח מבוסס נתונים שחושף את הפער ומספק בסיס לפעולה

**עיצוב:**
- אייקון מיקרוסקופ/מפה
- רשימת bullets עם checkmarks
- תיבה מודגשת לתוצר

**מקור:** סקר HIT 2023

---

### שקף 11: שלבים 2+3 - הכשרה וכלי

**סוג:** Solution Detail  
**Action Title:** הכשרה שמשנה גם מה מלמדים וגם איך – וכלי שמאפשר גישה שוויונית

**תוכן - שני חלקים:**

**שלב 2: הכשרה (טבלת 2×2)**

| ממד | מצב נוכחי | מצב רצוי |
|-----|-----------|----------|
| **תוכן** (מה) | מיומנויות מסורתיות בלבד | מיומנויות לעבודה משפטית משולבת AI |
| **פדגוגיה** (איך) | AI כאיום (זיהוי, איסור) | AI ככלי (שילוב, הנחיה) |

**שינוי נדרש:**
> ממרצים שנלחמים נגד AI → למרצים שעובדים עם AI

**שלב 3: כלי (תיבה)**

| מה | למה | תוצר |
|----|-----|------|
| כלי LLM מותאם לסטודנטי משפטים | סוגר פערי נגישות + פערי איכות | שימוש מונחה, שוויוני, מותאם תחום |

**נקודת מפתח:**
> גם Lexis+ AI מראה 17%+ הזיות – כלי לבד לא מספיק, צריך הכוונה

**עיצוב:**
- חלוקה לשני חלקים (הכשרה למעלה, כלי למטה)
- טבלת 2×2 להכשרה
- תיבה בודדת לכלי עם אייקון

**מקור:** Magesh et al. 2025

---

## חלק ג': מפרט טכני מפורט

### 3.1 קובץ CSS מלא

```css
/* mckinsey-rtl.css */
@import url('https://fonts.googleapis.com/css2?family=Assistant:wght@400;600;700&display=swap');

:root {
  /* Typography */
  --font-primary: 'Assistant', 'Arial Hebrew', sans-serif;
  
  /* Colors */
  --color-navy: #051C2C;
  --color-dark-gray: #333333;
  --color-medium-gray: #666666;
  --color-light-gray: #F5F5F5;
  --color-white: #FFFFFF;
  --color-accent-blue: #0066CC;
  --color-highlight: #00A3E0;
  --color-success: #00875A;
  --color-warning: #FF6B00;
  --color-danger: #E31B23;
  
  /* Table colors */
  --table-header-bg: #051C2C;
  --table-header-text: #FFFFFF;
  --table-row-odd: #FFFFFF;
  --table-row-even: #F8F9FA;
  --table-border: #E0E0E0;
  
  /* Spacing */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
  --spacing-xl: 32px;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body {
  direction: rtl;
  font-family: var(--font-primary);
  width: 960px;
  height: 540px;
  background: var(--color-white);
}

/* Slide Structure */
.slide {
  width: 960px;
  height: 540px;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.title-zone {
  height: 60px;
  padding: 15px 30px;
  background: var(--color-white);
  border-bottom: 2px solid var(--color-light-gray);
}

.content-zone {
  flex: 1;
  padding: 20px 30px;
  overflow: hidden;
}

.footer-zone {
  height: 35px;
  padding: 8px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 9px;
  color: var(--color-medium-gray);
  border-top: 1px solid var(--color-light-gray);
}

/* Typography */
.action-title {
  font-size: 24px;
  font-weight: 700;
  color: var(--color-navy);
  text-align: right;
  line-height: 1.3;
}

.subtitle {
  font-size: 14px;
  font-weight: 400;
  color: var(--color-medium-gray);
  margin-top: 4px;
}

h2 {
  font-size: 16px;
  font-weight: 600;
  color: var(--color-navy);
  margin-bottom: 12px;
}

p, li {
  font-size: 13px;
  line-height: 1.5;
  color: var(--color-dark-gray);
}

/* Tables */
table {
  width: 100%;
  border-collapse: collapse;
  direction: rtl;
  font-size: 12px;
}

th {
  background: var(--table-header-bg);
  color: var(--table-header-text);
  padding: 10px 12px;
  text-align: right;
  font-weight: 600;
  font-size: 12px;
}

td {
  padding: 8px 12px;
  text-align: right;
  border-bottom: 1px solid var(--table-border);
  font-size: 11px;
}

tr:nth-child(even) td {
  background: var(--table-row-even);
}

td.number {
  text-align: left;
  font-weight: 600;
}

td.highlight-red {
  color: var(--color-danger);
  font-weight: 700;
}

td.highlight-green {
  color: var(--color-success);
  font-weight: 600;
}

/* Lists */
ul {
  list-style-position: inside;
  padding-right: 0;
  margin-right: 10px;
}

li {
  margin-bottom: 6px;
}

/* Callout boxes */
.callout {
  padding: 12px 16px;
  border-radius: 4px;
  margin: 12px 0;
}

.callout-warning {
  background: #FFF3CD;
  border-right: 4px solid var(--color-warning);
}

.callout-danger {
  background: #FDECEA;
  border-right: 4px solid var(--color-danger);
}

.callout-success {
  background: #E8F5E9;
  border-right: 4px solid var(--color-success);
}

.callout-info {
  background: #E3F2FD;
  border-right: 4px solid var(--color-accent-blue);
}

/* Comparison layout */
.comparison-container {
  display: flex;
  gap: 20px;
  height: 100%;
}

.comparison-box {
  flex: 1;
  padding: 15px;
  border-radius: 6px;
}

.comparison-good {
  background: #E8F5E9;
  border: 2px solid var(--color-success);
}

.comparison-bad {
  background: #FDECEA;
  border: 2px solid var(--color-danger);
}

.comparison-box h3 {
  font-size: 14px;
  font-weight: 700;
  margin-bottom: 10px;
}

.comparison-good h3 {
  color: var(--color-success);
}

.comparison-bad h3 {
  color: var(--color-danger);
}

/* Flow diagram */
.flow-container {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
  margin: 20px 0;
}

.flow-box {
  padding: 15px 25px;
  border-radius: 8px;
  text-align: center;
  font-weight: 600;
  font-size: 14px;
}

.flow-arrow {
  font-size: 24px;
  color: var(--color-medium-gray);
}

/* Title slide specific */
.title-slide {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100%;
  text-align: center;
}

.title-slide .main-title {
  font-size: 32px;
  font-weight: 700;
  color: var(--color-navy);
  max-width: 800px;
  line-height: 1.4;
}

.title-slide .divider {
  width: 100px;
  height: 3px;
  background: var(--color-accent-blue);
  margin: 20px 0;
}

.title-slide .subtitle {
  font-size: 18px;
  color: var(--color-medium-gray);
}

/* Source citation */
.source {
  font-size: 9px;
  color: var(--color-medium-gray);
}

.slide-number {
  font-size: 10px;
  color: var(--color-medium-gray);
}
```

### 3.2 תבנית HTML לשקף

```html
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="mckinsey-rtl.css">
</head>
<body>
  <div class="slide">
    <div class="title-zone">
      <h1 class="action-title">[ACTION TITLE HERE]</h1>
    </div>
    <div class="content-zone">
      <!-- CONTENT HERE -->
    </div>
    <div class="footer-zone">
      <span class="source">מקור: [SOURCE]</span>
      <span class="slide-number">[N]</span>
    </div>
  </div>
</body>
</html>
```

### 3.3 סקריפט Node.js

```javascript
// build-presentation.js
const pptxgen = require("pptxgenjs");
const { html2pptx } = require("./html2pptx");

async function buildPresentation() {
  const pptx = new pptxgen();
  pptx.layout = "LAYOUT_16x9";
  pptx.title = "אסטרטגיית AI לפקולטה למשפטים";
  pptx.author = "עומר";
  
  // Add all 11 slides
  for (let i = 1; i <= 11; i++) {
    const slideNum = i.toString().padStart(2, '0');
    await html2pptx(`slide${slideNum}.html`, pptx);
  }
  
  await pptx.writeFile("AI-Strategy-Law-Faculty.pptx");
  console.log("Presentation created successfully!");
}

buildPresentation().catch(console.error);
```

---

## חלק ד': צ'קליסט איכות

### 4.1 בדיקות תוכן

- [ ] כל הכותרות הן Action Titles (משפטים שלמים עם תובנה)
- [ ] מבנה SCR ברור (שקפים 1-5 = S+C, שקפים 6-8 = מעבר, שקפים 9-11 = R)
- [ ] קטגוריזציית MECE (אין חפיפות, אין פערים)
- [ ] כל מקורות הנתונים מצוטטים
- [ ] הזרימה האופקית מספרת סיפור שלם (קריאת כותרות בלבד)
- [ ] הזרימה האנכית תומכת בטענות (תוכן כל שקף מוכיח את הכותרת)

### 4.2 בדיקות עיצוב

- [ ] פונט Assistant בכל המצגת
- [ ] יישור RTL תקין בכל הטקסטים
- [ ] צבעים עקביים לפי הפלטה
- [ ] טבלאות עם headers ברורים
- [ ] תרשימים עם callouts ברורים
- [ ] אין טקסט חתוך או חופף
- [ ] ניגודיות מספקת בין טקסט לרקע
- [ ] מרווחים עקביים

### 4.3 בדיקות טכניות

- [ ] קבצי HTML תקינים (960×540px)
- [ ] CSS נטען כראוי
- [ ] המרה ל-PPTX ללא שגיאות
- [ ] ולידציה ויזואלית של כל 11 השקפים
- [ ] קובץ PPTX נפתח ללא בעיות

---

## חלק ה': נתונים ומקורות

### 5.1 נתונים מרכזיים לשימוש

| נתון | ערך | מקור |
|------|-----|------|
| שיעור שימוש סטודנטים ב-AI | 86% | Digital Education Council 2024 |
| שיעור שימוש יומי | 25% | Digital Education Council 2024 |
| עלייה בשימוש ליצירת טקסט | 30%→64% | HEPI/Kortext 2025 |
| סטודנטים שמעתיקים ישירות | 18% | HEPI/Kortext 2025 |
| סטודנטים שמרגישים חוסר ידע | 58% | Digital Education Council 2024 |
| פער מגדרי בשימוש | 14 נק' אחוז | UC System 2024 |
| שיעור הזיות ChatGPT 4 | 58% | Dahl et al. 2024 |
| שיעור הזיות ChatGPT 3.5 | 69% | Dahl et al. 2024 |
| שיעור הזיות Llama 2 | 88% | Dahl et al. 2024 |
| שיעור הזיות Lexis+ AI | 17%+ | Magesh et al. 2025 |
| מקרי הזיות בבתי משפט | 486 | Dahl et al. 2024 |
| קנס Mata v. Avianca | $5,000 | 2023 |
| קנס Wadsworth v. Walmart | $3,000 | 2025 |
| סטודנטים ישראליים משתמשים | 70% | סקר HIT 2023 |

### 5.2 ציטוטים מרכזיים

> "אני לא גונב מאף אחד, אני פשוט מכין את עצמי טוב יותר לעולם החיצון. חבל שהאקדמיה לא מבינה את זה."
> — סטודנט ישראלי, סקר HIT 2023

> "60%+ מהסטודנטים מאמינים שמרצים אינם יכולים לצפות להתנהגות אתית ללא הדרכת AI"
> — סקר HIT 2023

### 5.3 רשימת מקורות מלאה

1. Digital Education Council Global AI Student Survey 2024 (3,839 סטודנטים, 16 מדינות)
2. HEPI/Kortext Student Generative AI Survey 2025 (1,041 סטודנטים, בריטניה)
3. UC System UCUES 2024 (53,450 סטודנטים, קליפורניה)
4. Dahl et al., "Large Legal Fictions" (2024), Journal of Legal Analysis, Stanford/Yale
5. Magesh et al., "Hallucination-Free?" (2025), Benchmarking legal AI tools
6. ABA Formal Opinion 512 (יולי 2024)
7. סקר HIT על סטודנטים ישראליים (700 סטודנטים, מאי 2023)
8. מדיניות אוניברסיטת בר-אילן (2024)
9. Northwestern-Anthropic Partnership (2024)

---

## חלק ו': הערות נוספות

### 6.1 התאמות אפשריות

- **אם יש יותר זמן:** להוסיף שקף תקציר מנהלים אחרי הכותרת
- **אם יש פחות זמן:** לאחד שקפים 10+11 לשקף אחד
- **אם רוצים להדגיש מחקר:** להוסיף שקף נפרד על מתודולוגיית המידול

### 6.2 נקודות לשימת לב בהצגה

1. **שקף 2 (הזירה):** להדגיש שהפקולטה "במרכז" אבל "עומדת במקום"
2. **שקף 4 (העלות):** נתוני ההזיות הם ה-"wow factor" - להדגיש
3. **שקף 7 (פער השימוש):** זה השקף שמראה את החזון בפעולה
4. **שקף 8 (מרצים):** זו נקודת המפתח - למה מרצים ולא תקנון

### 6.3 קבצים נדרשים

```
/project
├── mckinsey-rtl.css
├── slide01.html
├── slide02.html
├── slide03.html
├── slide04.html
├── slide05.html
├── slide06.html
├── slide07.html
├── slide08.html
├── slide09.html
├── slide10.html
├── slide11.html
├── build-presentation.js
├── html2pptx/
│   └── [library files]
└── output/
    └── AI-Strategy-Law-Faculty.pptx
```

---

**סוף מסמך ההנחיות**

*גרסה 1.0 | דצמבר 2025 | נוצר עבור פגישה עם סגנית הדיקן*
