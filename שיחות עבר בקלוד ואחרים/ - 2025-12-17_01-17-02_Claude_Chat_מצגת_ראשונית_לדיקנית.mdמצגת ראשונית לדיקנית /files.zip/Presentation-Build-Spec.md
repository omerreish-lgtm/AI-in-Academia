# AI Strategy Presentation - Build Spec

## Tech Stack
- html2pptx workflow (HTML → PPTX)
- 960×540px slides
- Hebrew RTL, Assistant font
- McKinsey methodology

## Colors
```
navy: #051C2C (titles)
accent: #0066CC (highlights)
success: #00875A (green)
danger: #E31B23 (red)
gray: #666666 (secondary)
table-header: #051C2C with white text
```

---

## SLIDES

### 1. Title
**Action Title:** הפקולטה למשפטים יכולה להוביל את מהפכת ה-AI בישראל – או לרדוף אחריה
**Subtitle:** הצעה לאסטרטגיית AI-first לפקולטה למשפטים, האוניברסיטה העברית
**Layout:** Centered, clean, divider line under title

---

### 2. Arena
**Action Title:** כל השחקנים סביב הפקולטה כבר זזים – הפקולטה עומדת במקום

**Visual:** Central diagram - Faculty in middle, 4 pressure arrows:
- Top: אין הנחיות מל"ג | מחקר כבר נעזר ב-AI
- Left: ABA Opinion 512 | משרדים מאמצים Harvey, CoCounsel  
- Right: בר-אילן: מדיניות מלאה (2024)
- Bottom: 86% סטודנטים משתמשים | 486 מקרי הזיות בבתי משפט

**Callout box:** אף פקולטה למשפטים בישראל לא פרסמה הנחיות AI לסטודנטים

**Source:** Digital Education Council 2024; ABA 2024

---

### 3. Triple Problem
**Action Title:** שלוש רמות, שורש אחד: היעדר חזון AI-first

**Table (3 rows):**
| רמה | מצב נוכחי | תוצאה |
|-----|-----------|-------|
| מוסדית | אין מדיניות, עיוורון או איסור | אי-ודאות, "אזור אפור" |
| מרצים | חוסר אוריינות, חשש, ניתוק | לא יכולים להנחות |
| סטודנטים | 86% משתמשים ללא הכוונה | לא מוכנים לשוק |

**Callout (red):** שורש: התייחסות ל-AI כאיום – לא כתשתית חדשה

**Source:** Digital Education Council 2024; סקר HIT 2023

---

### 4. Cost
**Action Title:** היעדר מדיניות יוצר אי-שוויון רב-ממדי בין הסטודנטים

**Table 1 - Gaps:**
| פער | נתון |
|-----|------|
| ידע ומיומנות | 58% מרגישים חוסר ידע |
| נגישות כלכלית | ChatGPT Plus: $20/חודש |
| רקע טכנולוגי | 14 נק' אחוז פער מגדרי |
| איכות שימוש | 18% מעתיקים ישירות |

**Table 2 - Hallucination rates (highlight red):**
| מודל | שיעור הזיות |
|------|-------------|
| ChatGPT 4 | 58% |
| ChatGPT 3.5 | 69% |
| Llama 2 | 88% |
| Lexis+ AI | 17%+ |

**Source:** HEPI 2025; Dahl et al. 2024

---

### 5. Urgency
**Action Title:** חלון ההזדמנות נסגר – עלות ההמתנה גדלה מחודש לחודש

**Timeline (horizontal, 3 points):**

**קרה:**
- 486 מקרי הזיות AI בבתי משפט (324 בארה"ב)
- Mata v. Avianca (2023): קנס $5,000
- Wadsworth v. Walmart (2025): קנס $3,000

**קורה עכשיו:**
- בר-אילן: מדיניות + צ'אטבוט (2024)
- ABA Opinion 512 (יולי 2024)
- משרדים מטמיעים Harvey, CoCounsel

**יקרה אם נמתין:**
> "בוגרי הפקולטה ייכנסו לשוק שדורש מיומנויות שלא לימדנו"

**Visual:** Red arrow showing growing gap

**Source:** Dahl et al. 2024; ABA 2024

---

### 6. Vision
**Action Title:** פקולטה עם תרבות AI-first: מדיניות ברורה, סגל מיומן, סטודנטים עם חשיבה ביקורתית

**Table - 4 principles:**
| עיקרון | משמעות |
|--------|--------|
| עידוד, לא רק היתר | "מעודדים להשתמש נכון" |
| הסתגלות, לא כלים | ללמד יכולת למידה |
| שילוב, לא החלפה | AI כמגביר יכולות |
| שקיפות | מדיניות ברורה |

**Info box:** מודל השראה: שותפות Northwestern-Anthropic

**Source:** Northwestern-Anthropic 2024

---

### 7. Usage Gap
**Action Title:** ההבדל בין שימוש מיומן לבעייתי הוא ההבדל בין למידה לרמאות

**Two side-by-side tables:**

**Left (GREEN) - שימוש מיומן:**
| פעולה | תוצאה |
|-------|-------|
| הסבר מושגים | הבנה מעמיקה |
| סיעור מוחות | רעיונות חדשים |
| תרגול IRAC | הכנה לבחינה |
| עריכה | כתיבה טובה יותר |
| אימות | בקרת איכות |

**Right (RED) - שימוש בעייתי:**
| פעולה | תוצאה |
|-------|-------|
| העתקה | אי-למידה |
| הזיות | אסמכתאות בדויות |
| תלות | החמצת שגיאות |
| אי-אימות | טעויות חמורות |

**Divider text:** מה מבדיל? **הכוונה + מודעות + כלים**

---

### 8. Lecturers as Change Agents
**Action Title:** השינוי יעבור דרך המרצים – הם נקודת המנוף

**Why lecturers (3 bullets):**
- ממוקמים בין המוסד לסטודנטים
- קובעים מדיניות בפועל
- מעצבים תרבות שימוש

**Table - 3 barriers:**
| מחסום | נתון |
|-------|------|
| מודעות | פער בין 86% בפועל להערכות מרצים |
| מיומנויות | 70% סטודנטים חושבים שמרצים לא יזהו |
| כלים | אין כלים משפטיים ייעודיים |

**Visual:** Diagram: מוסד → מרצים → סטודנטים (barriers as red X)

**Source:** סקר HIT 2023

---

### 9. Solution Overview
**Action Title:** שלושה שלבים: קודם להבין, אחר כך להכשיר, ולבסוף לצייד

**Flow diagram (horizontal):**
```
[מידול] → [הכשרה] → [כלי]
   ↓          ↓         ↓
להבין     להכשיר    לצייד
```

**Table:**
| שלב | פותר מחסום | תוצאה |
|-----|------------|-------|
| מידול | מודעות | תמונת מצב מבוססת נתונים |
| הכשרה | מיומנויות | מרצים מסוגלים להנחות |
| כלי | כלים | גישה שוויונית ומונחית |

---

### 10. Stage 1 - Modeling
**Action Title:** אי אפשר לפתור בעיה שלא רואים – מתחילים במיפוי המציאות

**What:** מיפוי דפוסי השימוש בפועל של סטודנטי הפקולטה

**Why (bullets):**
- הנחות המרצים לא תואמות את המציאות
- 86% משתמשים, 0% מדיניות = פער עצום

**Quote box:** "60%+ מהסטודנטים מאמינים שמרצים לא יכולים לצפות להתנהגות אתית ללא הדרכת AI"

**How (checkmarks):**
- ☑️ סקר סטודנטים אנונימי
- ☑️ ראיונות עומק עם מרצים
- ☑️ ניתוח השוואתי למחקרים גלובליים

**Output box:** דו"ח מבוסס נתונים שחושף את הפער ומספק בסיס לפעולה

**Source:** סקר HIT 2023

---

### 11. Stages 2+3 - Training & Tool
**Action Title:** הכשרה שמשנה גם מה מלמדים וגם איך – וכלי שמאפשר גישה שוויונית

**Stage 2 - Training (2×2 table):**
| ממד | מצב נוכחי | מצב רצוי |
|-----|-----------|----------|
| תוכן | מיומנויות מסורתיות | מיומנויות לעבודה משולבת AI |
| פדגוגיה | AI כאיום | AI ככלי |

**Arrow text:** ממרצים נגד AI → למרצים עם AI

**Stage 3 - Tool (single box):**
| מה | למה | תוצר |
|----|-----|------|
| כלי LLM מותאם למשפטים | סוגר פערי נגישות + איכות | שימוש מונחה, שוויוני |

**Warning callout:** גם Lexis+ AI מראה 17%+ הזיות – כלי לבד לא מספיק

**Source:** Magesh et al. 2025

---

## Validation Checklist
- [ ] All titles are Action Titles (full sentences)
- [ ] RTL alignment correct
- [ ] No text cutoff/overlap
- [ ] Sources on every data slide
- [ ] Colors consistent
- [ ] PPTX opens correctly in PowerPoint
