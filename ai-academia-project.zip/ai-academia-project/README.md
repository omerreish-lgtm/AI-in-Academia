# AI in Academia – Hebrew University Law Faculty

> Strategic initiative to develop AI framework for legal education

## Status: 🚧 Active Development

**Current Phase:** Post-initial meeting, preparing detailed proposal

---

## Structure

```
├── logs/
│   └── PROJECT_LOG.md      # Main timeline & index
├── meetings/
│   ├── meeting_renana_shaked.md
│   ├── meeting_avi_asban.md
│   └── meeting_keren_atinger.md
└── docs/
    └── [pending]
```

---

## Start Here

→ [Project Log](logs/PROJECT_LOG.md)
